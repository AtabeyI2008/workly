const CONFIG = {
  siteName: "BizNet",
  version: "1.0.0",
  commissionRate: 0.15,
  minWithdraw: 20.0,
  subscriptions: { basic: 10, pro: 25, premium: 50 },
  simulatePayments: true
};
export default CONFIG;

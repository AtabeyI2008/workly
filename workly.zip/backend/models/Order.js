import mongoose from "mongoose";
const orderSchema = new mongoose.Schema({
  job:{type:mongoose.Schema.Types.ObjectId,ref:"Job",required:true},
  buyer:{type:mongoose.Schema.Types.ObjectId,ref:"User",required:true},
  seller:{type:mongoose.Schema.Types.ObjectId,ref:"User",required:true},
  amount:{type:Number,required:true},
  currency:{type:String,default:"AZN"},
  status:{type:String,enum:["pending","paid","cancelled","refunded"],default:"pending"},
  providerTransactionId:{type:String,default:null},
  createdAt:{type:Date,default:Date.now}
});
export default mongoose.model("Order", orderSchema);

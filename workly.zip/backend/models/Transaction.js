import mongoose from "mongoose";
const transactionSchema = new mongoose.Schema({
  order:{type:mongoose.Schema.Types.ObjectId,ref:"Order"},
  user:{type:mongoose.Schema.Types.ObjectId,ref:"User"},
  type:{type:String,enum:["payment","commission","payout","refund"],required:true},
  amount:{type:Number,required:true},
  currency:{type:String,default:"AZN"},
  meta:{type:Object},
  createdAt:{type:Date,default:Date.now}
});
export default mongoose.model("Transaction", transactionSchema);

import mongoose from "mongoose";
const subSchema = new mongoose.Schema({
  user:{type:mongoose.Schema.Types.ObjectId,ref:"User",required:true},
  plan:{type:String,enum:["basic","pro","premium"],required:true},
  amount:{type:Number,required:true},
  currency:{type:String,default:"AZN"},
  startAt:{type:Date,default:Date.now},
  endAt:{type:Date,required:true},
  active:{type:Boolean,default:true}
});
export default mongoose.model("Subscription", subSchema);

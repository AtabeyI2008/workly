import mongoose from "mongoose";
const jobSchema = new mongoose.Schema({
  title:{type:String,required:true},
  description:{type:String},
  price:{type:Number,required:true},
  currency:{type:String,default:"AZN"},
  city:String,
  category:String,
  isFeatured:{type:Boolean,default:false},
  featureExpiresAt:{type:Date,default:null},
  postedBy:{type:mongoose.Schema.Types.ObjectId,ref:"User",required:true},
  createdAt:{type:Date,default:Date.now},
  status:{type:String,enum:["active","closed","draft"],default:"active"}
});
export default mongoose.model("Job", jobSchema);

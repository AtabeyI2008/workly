import mongoose from "mongoose";
const userSchema = new mongoose.Schema({
  name:{type:String,required:true},
  email:{type:String,required:true,unique:true,lowercase:true},
  passwordHash:{type:String},
  userType:{type:String,enum:["freelancer","company","admin","user"],default:"user"},
  companyName:String,
  city:String,
  walletBalance:{type:Number,default:0},
  createdAt:{type:Date,default:Date.now},
  subscribedPlan:{type:String,enum:["basic","pro","premium",null],default:null},
  subscriptionExpiresAt:{type:Date,default:null},
  kycVerified:{type:Boolean,default:false}
});
export default mongoose.model("User", userSchema);

import User from "../models/User.js";
export async function me(req,res){
  const u = await User.findById(req.user._id);
  res.json({ id:u._id, name:u.name, email:u.email, userType:u.userType, walletBalance:u.walletBalance, subscribedPlan:u.subscribedPlan, subscriptionExpiresAt:u.subscriptionExpiresAt });
}

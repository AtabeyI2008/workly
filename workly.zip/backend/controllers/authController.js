import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import User from "../models/User.js";
import dotenv from "dotenv";
dotenv.config();
const JWT_SECRET = process.env.JWT_SECRET;
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || "7d";

export async function register(req,res){
  const { name,email,password,userType,companyName,city } = req.body;
  if(!email||!password||!name) return res.status(400).json({message:"name,email,password required"});
  const exists = await User.findOne({email});
  if(exists) return res.status(400).json({message:"Email already used"});
  const passwordHash = await bcrypt.hash(password,10);
  const u = new User({name,email,passwordHash,userType:userType||"user",companyName,city});
  await u.save();
  const token = jwt.sign({ sub: u._id, email: u.email }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
  res.json({ token, user: { id:u._id, name:u.name, email:u.email, userType:u.userType } });
}

export async function login(req,res){
  const { email,password } = req.body;
  if(!email||!password) return res.status(400).json({message:"email and password required"});
  const user = await User.findOne({ email });
  if(!user) return res.status(400).json({message:"Invalid credentials"});
  const ok = await bcrypt.compare(password, user.passwordHash || "");
  if(!ok) return res.status(400).json({message:"Invalid credentials"});
  const token = jwt.sign({ sub: user._id, email: user.email }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
  res.json({ token, user: { id:user._id, name:user.name, email:user.email, userType:user.userType } });
}

import Payout from "../models/Payout.js";
import User from "../models/User.js";
import CONFIG from "../config/config.js";

export async function requestPayout(req,res){
  const { amount, method } = req.body;
  if(!amount || amount < CONFIG.minWithdraw) return res.status(400).json({message:`Minimum withdraw is ${CONFIG.minWithdraw} AZN`});
  const user = await User.findById(req.user._id);
  if(user.walletBalance < amount) return res.status(400).json({message:"Insufficient balance"});
  const payout = new Payout({ user:user._id, amount, method, status:"pending" });
  await payout.save();
  // deduct balance immediately or on admin confirm depending on policy; here we deduct immediately
  user.walletBalance = Math.round((user.walletBalance - amount) * 100) / 100;
  await user.save();
  res.json({ ok:true, payoutId:payout._id });
}

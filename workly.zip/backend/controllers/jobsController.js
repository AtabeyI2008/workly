import Job from "../models/Job.js";
export async function createJob(req,res){
  const { title, description, price, city, category, isFeatured } = req.body;
  if(!title||!price) return res.status(400).json({message:"title and price required"});
  if(req.user.userType === "company"){
    if(!req.user.subscribedPlan || (req.user.subscriptionExpiresAt && req.user.subscriptionExpiresAt < new Date())){
      return res.status(403).json({message:"Company must have an active subscription to post jobs"});
    }
  }
  const job = new Job({ title, description, price, city, category, isFeatured:!!isFeatured, postedBy:req.user._id });
  await job.save();
  res.json({ ok:true, job });
}
export async function listJobs(req,res){
  const jobs = await Job.find().sort({createdAt:-1}).populate("postedBy","name companyName userType");
  res.json(jobs);
}
export async function getJob(req,res){
  const job = await Job.findById(req.params.id).populate("postedBy","name companyName userType");
  if(!job) return res.status(404).json({message:"Job not found"});
  res.json(job);
}
export async function deleteJob(req,res){
  const job = await Job.findById(req.params.id);
  if(!job) return res.status(404).json({message:"Job not found"});
  if(!job.postedBy.equals(req.user._id) && req.user.userType !== "admin") return res.status(403).json({message:"Not allowed"});
  await job.remove();
  res.json({ ok:true });
}

import Order from "../models/Order.js";
import Job from "../models/Job.js";
import Transaction from "../models/Transaction.js";
import User from "../models/User.js";
import { applyCommission } from "../utils/applyCommission.js";
import { chargeCardSimulated } from "../utils/paymentProviderStub.js";
import CONFIG from "../config/config.js";

export async function createOrder(req,res){
  const { jobId, cardInfo } = req.body;
  const job = await Job.findById(jobId);
  if(!job) return res.status(404).json({message:"Job not found"});
  const seller = await User.findById(job.postedBy);
  if(!seller) return res.status(404).json({message:"Seller not found"});

  const order = new Order({ job:job._id, buyer:req.user._id, seller:seller._id, amount:job.price, currency:job.currency, status:"pending" });
  await order.save();

  if(CONFIG.simulatePayments){
    const resCharge = await chargeCardSimulated({ amount: job.price, currency: job.currency, cardInfo, metadata:{orderId:order._id} });
    if(!resCharge.success){ order.status="cancelled"; await order.save(); return res.status(400).json({message:"Payment failed"}); }
    order.status = "paid";
    order.providerTransactionId = resCharge.providerTransactionId;
    await order.save();

    const { commission, sellerShare } = applyCommission(job.price);
    await Transaction.create({ order:order._id, user:null, type:"commission", amount:commission, currency:job.currency, meta:{orderId:order._id} });
    await Transaction.create({ order:order._id, user:seller._id, type:"payment", amount:sellerShare, currency:job.currency, meta:{orderId:order._id} });

    seller.walletBalance = Math.round((seller.walletBalance + sellerShare) * 100) / 100;
    await seller.save();

    return res.json({ ok:true, orderId:order._id, commission, sellerShare });
  }

  return res.json({ ok:false, message:"Real provider not configured" });
}

export async function webhookHandler(req,res){
  res.json({ ok:true });
}

import Subscription from "../models/Subscription.js";
import User from "../models/User.js";
import CONFIG from "../config/config.js";
import Transaction from "../models/Transaction.js";

export async function buySubscription(req,res){
  const { plan } = req.body;
  if(!["basic","pro","premium"].includes(plan)) return res.status(400).json({message:"Invalid plan"});
  const amount = CONFIG.subscriptions[plan];
  const startAt = new Date();
  const endAt = new Date(startAt);
  endAt.setMonth(endAt.getMonth()+1);
  const subscription = new Subscription({ user:req.user._id, plan, amount, startAt, endAt, active:true });
  await subscription.save();
  const u = await User.findById(req.user._id);
  u.subscribedPlan = plan;
  u.subscriptionExpiresAt = endAt;
  await u.save();
  await Transaction.create({ user:u._id, type:"payment", amount, currency:"AZN", meta:{plan} });
  res.json({ ok:true, subscription });
}

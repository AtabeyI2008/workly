# BizNet Backend (skeleton)

## Setup

1. Copy `.env.example` to `.env` and fill values.
2. Install dependencies:
```
npm install
```
3. Start local MongoDB and then:
```
npm run dev
```

## Endpoints (important)
- POST /api/auth/register
- POST /api/auth/login
- GET /api/jobs
- POST /api/jobs (auth)
- POST /api/orders/create (auth)
- POST /api/subscriptions/buy (auth)
- POST /api/payouts (auth)
- GET /api/users/me (auth)
- GET /api/transactions/me (auth)

Payment is simulated in `utils/paymentProviderStub.js`. Commission applied is 15% via `utils/applyCommission.js`.


import CONFIG from "../config/config.js";
export function applyCommission(amount){
  const rate = CONFIG.commissionRate ?? 0.15;
  const commission = Math.round(amount * rate * 100) / 100;
  const sellerShare = Math.round((amount - commission) * 100) / 100;
  return { commission, sellerShare };
}

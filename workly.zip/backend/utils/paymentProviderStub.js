export async function chargeCardSimulated({amount,currency,cardInfo,metadata}){
  await new Promise(r=>setTimeout(r,500));
  return { success:true, providerTransactionId:`SIM-${Date.now()}`, amount, currency, metadata };
}
export function verifyWebhookSimulated(){ return true; }

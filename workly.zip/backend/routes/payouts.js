import express from "express";
import { requestPayout } from "../controllers/payoutsController.js";
import { authMiddleware } from "../middleware/auth.js";
const router = express.Router();
router.post("/", authMiddleware, requestPayout);
export default router;

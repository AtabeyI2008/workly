import express from "express";
import { buySubscription } from "../controllers/subscriptionsController.js";
import { authMiddleware } from "../middleware/auth.js";
const router = express.Router();
router.post("/buy", authMiddleware, buySubscription);
export default router;

import express from "express";
import { createOrder, webhookHandler } from "../controllers/ordersController.js";
import { authMiddleware } from "../middleware/auth.js";
const router = express.Router();
router.post("/create", authMiddleware, createOrder);
router.post("/webhook", express.raw({ type: '*/*' }), webhookHandler);
export default router;

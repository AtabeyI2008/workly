import express from "express";
import { authMiddleware } from "../middleware/auth.js";
import { me } from "../controllers/usersController.js";
const router = express.Router();
router.get("/me", authMiddleware, me);
export default router;

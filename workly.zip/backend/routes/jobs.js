import express from "express";
import { createJob, listJobs, getJob, deleteJob } from "../controllers/jobsController.js";
import { authMiddleware } from "../middleware/auth.js";
const router = express.Router();
router.get("/", listJobs);
router.get("/:id", getJob);
router.post("/", authMiddleware, createJob);
router.delete("/:id", authMiddleware, deleteJob);
export default router;

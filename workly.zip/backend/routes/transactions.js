import express from "express";
import Transaction from "../models/Transaction.js";
import { authMiddleware, adminOnly } from "../middleware/auth.js";
const router = express.Router();
router.get("/me", authMiddleware, async (req,res)=>{ const txns = await Transaction.find({ user:req.user._id }).sort({createdAt:-1}); res.json(txns); });
router.get("/all", authMiddleware, adminOnly, async (req,res)=>{ const txns = await Transaction.find().sort({createdAt:-1}); res.json(txns); });
export default router;

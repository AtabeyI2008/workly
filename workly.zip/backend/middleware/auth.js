import jwt from "jsonwebtoken";
import User from "../models/User.js";
import dotenv from "dotenv";
dotenv.config();
const JWT_SECRET = process.env.JWT_SECRET;
export async function authMiddleware(req,res,next){
  const authHeader = req.headers.authorization;
  if(!authHeader || !authHeader.startsWith("Bearer ")) return res.status(401).json({message:"Unauthorized"});
  const token = authHeader.split(" ")[1];
  try{
    const payload = jwt.verify(token, JWT_SECRET);
    const user = await User.findById(payload.sub);
    if(!user) return res.status(401).json({message:"Unauthorized"});
    req.user = user;
    next();
  }catch(err){
    return res.status(401).json({message:"Invalid token"});
  }
}
export function adminOnly(req,res,next){
  if(!req.user || req.user.userType!=="admin") return res.status(403).json({message:"Forbidden - admin only"});
  next();
}

import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import dotenv from "dotenv";
dotenv.config();

import { connectDB } from "./utils/db.js";
import config from "./config/config.js";

import authRoutes from "./routes/auth.js";
import jobsRoutes from "./routes/jobs.js";
import ordersRoutes from "./routes/orders.js";
import subscriptionsRoutes from "./routes/subscriptions.js";
import payoutsRoutes from "./routes/payouts.js";
import transactionsRoutes from "./routes/transactions.js";
import usersRoutes from "./routes/users.js";

import errorHandler from "./middleware/errorHandler.js";

const app = express();
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: "30kb" }));
app.use(express.urlencoded({ extended:true }));

app.use("/api/auth", authRoutes);
app.use("/api/jobs", jobsRoutes);
app.use("/api/orders", ordersRoutes);
app.use("/api/subscriptions", subscriptionsRoutes);
app.use("/api/payouts", payoutsRoutes);
app.use("/api/transactions", transactionsRoutes);
app.use("/api/users", usersRoutes);

app.get("/", (req,res)=> res.json({ ok:true, site: config.siteName }));

app.use(errorHandler);

const PORT = process.env.PORT || 3000;
(async ()=>{
  try{
    await connectDB(process.env.MONGO_URI || "mongodb://127.0.0.1:27017/biznet");
    app.listen(PORT, ()=> console.log(`Server listening on http://localhost:${PORT}`));
  }catch(err){
    console.error("Failed to start", err);
    process.exit(1);
  }
})();

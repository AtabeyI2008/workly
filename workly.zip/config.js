// Auto-generated config for frontend-backend integration
window.APP_CONFIG = window.APP_CONFIG || {
  BACKEND_ENABLED: true,
  API_BASE: "http://localhost:3000/api",
  COMMISSION_RATE: 0.15
};
console.log("APP_CONFIG loaded:", window.APP_CONFIG);
